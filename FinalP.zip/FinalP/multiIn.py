import speech_recognition as sr
import pyaudio
import multiprocessing
import sys
import wave
import time
import Queue


FORMAT = pyaudio.paInt16
CHANNELS = 2
RATE = 44100
CHUNK = 1024
RECORD_SECONDS = 5
WAVE_OUTPUT_FILENAME = "file.wav"


class MultiIn():
    q = Queue.Queue()
    flag = False

    def get_command(self):
        # console commands
        if not MultiIn.q.empty():
            return MultiIn.q.get()
        else:
            return "NoOp"

    def voice_command(self):
        p = multiprocessing.Process(target=self.worker)
        p.daemon = True
        p.start()

        # AUDIO_FILE = path.join(path.dirname(path.realpath(__file__)), "./wav/test.wav")


        return


    def multi_command(self):

        while True:
            command = raw_input('$ ')
            MultiIn.q.put(command)
            print ('Corbett: ' + command)

            if command == '`':

                jobs = []
                p = multiprocessing.Process(target=self.worker)
                jobs.append(p)
                p.start()

                # AUDIO_FILE = path.join(path.dirname(path.realpath(__file__)), "./wav/test.wav")
                AUDIO_FILE = "1.wav"
                r = sr.Recognizer()
                raw_input("$")
                with sr.AudioFile(AUDIO_FILE) as source:
                    audio = r.record(source)  # read the entire audio file

                # recognize speech using Google Speech Recognition
                try:
                    print("Text: " + r.recognize_google(audio))
                except sr.UnknownValueError:
                    print("Google Speech Recognition could not understand audio")
                except sr.RequestError as e:
                    print("Could not request results from Google Speech Recognition service; {0}".format(e))

            if command == 'exit':
                print('Corbett: Goodbye')
                sys.exit()
                return

    def worker(self):
        print 'Worker'
        audio = pyaudio.PyAudio()

        file_time = time.asctime(time.localtime(time.time()))
        # file_name = "./wav/" + file_time[11:19] + ".wav"
        file_name = "1.wav"
        # start Recording
        stream = audio.open(format=FORMAT, channels=CHANNELS,
                            rate=RATE, input=True,
                            frames_per_buffer=CHUNK)
        print "recording..."
        frames = []

        for i in range(0, int(RATE / CHUNK * RECORD_SECONDS)):
            data = stream.read(CHUNK)
            frames.append(data)
        print "finished recording"

        # stop Recording
        stream.stop_stream()
        stream.close()
        audio.terminate()

        waveFile = wave.open(file_name, 'wb')
        waveFile.setnchannels(CHANNELS)
        waveFile.setsampwidth(audio.get_sample_size(FORMAT))
        waveFile.setframerate(RATE)
        waveFile.writeframes(b''.join(frames))
        waveFile.close()
        MultiIn.flag = True

        while True:
            if MultiIn.flag == True:
                AUDIO_FILE = "1.wav"
                print("2")
                r = sr.Recognizer()
                with sr.AudioFile(AUDIO_FILE) as source:
                    audio = r.record(source)  # read the entire audio file

                # recognize speech using Google Speech Recognition
                try:
                    text = r.recognize_google(audio)
                    print("Command: " + text)
                    MultiIn.q.put(text)
                except sr.UnknownValueError:
                    print("Google Speech Recognition could not understand audio")
                except sr.RequestError as e:
                    print("Could not request results from Google Speech Recognition service; {0}".format(e))
                MultiIn.flag = False
            else:
                time.sleep(0.5)
        return



