import Queue

class CommandQ:

    def __init__(self):
        q = Queue.Queue()

    def add_command(self, command):
        self.q.append(command)

    def get_command(self):
        if not self.q.empty():
            return self.q.get()
        else:
            return "NoOp"